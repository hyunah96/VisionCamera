# My First Project > 2025-12-05 11:28am
https://universe.roboflow.com/mesupper-frame/my-first-project-oorsx

Provided by a Roboflow user
License: CC BY 4.0

